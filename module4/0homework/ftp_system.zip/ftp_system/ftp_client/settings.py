# -*- coding: utf-8 -*-
# @Time    : 2018/12/18 11:55
# @Author  : Xiao


import os


PROJECT_PATH = os.path.dirname(os.path.abspath(__file__))
DOWNLOAD_PATH = os.path.join(PROJECT_PATH, "download")
SERVER_IP = "localhost"
SERVER_PORT = 8089