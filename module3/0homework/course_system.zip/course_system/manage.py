# -*- coding: utf-8 -*-
# @Time    : 2018/12/11 19:44
# @Author  : Xiao


from bin.main import run


if __name__ == "__main__":
    run()